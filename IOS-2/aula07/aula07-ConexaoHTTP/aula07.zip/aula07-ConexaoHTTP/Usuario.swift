//
//  Usuario.swift
//  aula07-ConexaoHTTP
//
//  Created by HC2MAC017 on 02/05/2018.
//  Copyright © 2018 IESB. All rights reserved.
//

import Foundation

class Usuario: Codable {
    
    var id: Int
    var name: String
    var username: String
    
}
